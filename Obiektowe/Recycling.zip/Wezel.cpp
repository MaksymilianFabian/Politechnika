#include "Wezel.h"

Wezel::Wezel() {
    //Constructor
}

Wezel::~Wezel() {
    std::cout << "Destrukcja obiektu Wezel" << std::endl;
}

