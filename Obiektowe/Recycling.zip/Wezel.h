#ifndef WEZEL_H
#define WEZEL_H

#include <iostream>
#include <map>
#include <memory>

class Wezel {
public:
    Wezel();
    ~Wezel();  // destruktor
    std::shared_ptr<Wezel> next;
    std::weak_ptr<Wezel> prev;

private:
    std::map<Wezel*, bool> polaczenia;
};

#endif
